<?php
	//Session starten
	session_start();
	
	error_reporting(E_ERROR);
?>
<!--
************************************************************************
Aufgabe: wako_start
v. 1.0 Sandro Ropelato, 21. September 2006
v. 1.1 Luigi Cavuoti, 19. April 2009
v. 1.2 Andrea Casauro, 1. Juni 2018
************************************************************************
-->
<div class="standard">



<b>Startseite</b>
<br><br>
Herzlich willkommen beim Beispielwebshop...



</div>
